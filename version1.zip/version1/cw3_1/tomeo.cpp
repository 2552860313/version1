#include <iostream>
#include <QApplication>
#include <QtMultimediaWidgets/QVideoWidget>
#include <QMediaPlaylist>
#include <string>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QHBoxLayout>
#include <QtCore/QFileInfo>
#include <QtWidgets/QFileIconProvider>
#include <QImageReader>
#include <QtCore/QDir>
#include <QtCore/QDirIterator>
#include <QLabel>
#include <QScrollArea>
#include <QSlider>
#include "the_player.h"
#include "the_button.h"
#include "PlayerSlider.h"
#include "buttom_label.h"
#include "videowindow.h"


using namespace std;

// read in videos and thumbnails to this directory
vector<TheButtonInfo> getInfoIn (string loc) {

    vector<TheButtonInfo> out =  vector<TheButtonInfo>(); // container list for all the information

    QDirIterator it(QString::fromStdString(loc), QDir::Files);

    while (it.hasNext()) { // for all files
		QString f = it.next();

#if defined(_WIN32)
            if (f.contains(".wmv"))  { // windows
#else
            if (f.contains(".mp4"))  { // mac/linux
#endif

        if (!f.contains(".png")) { // if it isn't an image
            QString thumb = f.left( f .length() - 3) +"png";
            if (QFile(thumb).exists()) { // but a png thumbnail exists
                QImageReader *imageReader = new QImageReader(thumb);
                    QImage sprite = imageReader->read();
                    if (!sprite.isNull()) {
                        QIcon* ico = new QIcon(QPixmap::fromImage(sprite));
                        QUrl* url = new QUrl(QUrl::fromLocalFile(f)); //URL convert the file location to a generic url
						out.push_back(TheButtonInfo(url, ico)); // add to the output list
						//++;

					}
					else
						qDebug() << "warning: skipping video because I couldn't process thumbnail " << thumb ;
            }
            else
				qDebug() << "warning: skipping video because I couldn't find thumbnail " << thumb;
        }
            }
    }
    return out;
}


int main(int argc, char *argv[]) {

    // let's just check that Qt is operational first
	qDebug() << "Qt version: " << QT_VERSION_STR;QApplication app(argc, argv);

    // collect all the videos in the folder
    vector<TheButtonInfo> videos = getInfoIn("C:\\Users\\31337\\Desktop\\junior\\User Interface\\2811_cw3\\videos");

    if (videos.size() == 0) {
        qDebug() << "no videos found"; exit(-1);}

    // the widget that will show the video
    videowindow *videoWidget = new videowindow;

    // the QMediaPlayer which controls the playback
    ThePlayer *player = new ThePlayer;player->setVideoOutput(videoWidget); 

    // a row of buttons
    QWidget *buttonWidget = new QWidget();std::vector<TheButton*> buttons;

    // the buttons are arranged horizontally
    QVBoxLayout *layout = new QVBoxLayout();buttonWidget->setLayout(layout);
    buttomlabel *lab1 = new buttomlabel();

    // create the four buttons
    for ( int i = 0; i < 6; i++ ) {
        TheButton *button = new TheButton(buttonWidget);
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), player, SLOT (jumpTo(TheButtonInfo* )));
        button->connect(button, SIGNAL(jumpTo(TheButtonInfo* )), lab1, SLOT (setbutText(TheButtonInfo*)));
        button->setMaximumWidth(210);button->setMaximumHeight(140);
        buttons.push_back(button);layout->addWidget(button);
        button->init(&videos.at(i)); }

    // tell the player what buttons and videos are available
    player->setContent(&buttons, & videos);

    //scrollarea
    QScrollArea* scroll = new QScrollArea();scroll->setMinimumWidth(190);
    buttonWidget->setGeometry(0, 0,160,750);scroll->setWidget(buttonWidget);

    // create the main window and layout
    QWidget window;QVBoxLayout *top = new QVBoxLayout();

    window.setWindowTitle("tomeo");PlayerSlider *slider = new PlayerSlider();
    slider->setOrientation(Qt::Horizontal);

    PlayerSlider *slider_volume = new PlayerSlider();slider_volume->setOrientation(Qt::Horizontal);

    QTimer *SlideTimer = new QTimer(player);SlideTimer->setInterval(1000); // 1000ms is one second between ...
    SlideTimer->start();slider->getplayer(player);
    player->getslider(slider,slider_volume);player->gertimer(SlideTimer);
    QTimer::connect(SlideTimer, SIGNAL(timeout()), slider, SLOT(onTimerOut()));

    PlayerSlider::connect(slider,SIGNAL(sliderMoved(int)),player,SLOT(progress_moved()));
    PlayerSlider::connect(slider,SIGNAL(sliderReleased()),player,SLOT(progress_released()));

    PlayerSlider::connect(slider,SIGNAL(sliderPressed()),player,SLOT(slider_clicked()));
    PlayerSlider::connect(slider_volume,SIGNAL(sliderMoved(int)),player,SLOT(slider_clicked2()));

    QPushButton* b_start = new QPushButton();QPushButton* b_pase = new QPushButton();
    QPushButton* fullScreen = new QPushButton();

    b_start->setText("START");b_pase->setText("PAUSE");fullScreen->setText("FullScreen");
    QPushButton::connect(b_pase,SIGNAL(clicked()),player,SLOT(pause()));
    QPushButton::connect(b_start,SIGNAL(clicked()),player,SLOT(play()));
    QLabel* time = new QLabel("TIME");time->setStyleSheet(" color : green;");

    QLabel* volume = new QLabel("Volume");volume->setStyleSheet(" color : green;");


    QVBoxLayout *controlbar1 =new QVBoxLayout();QHBoxLayout *controlbar =new QHBoxLayout();
    QHBoxLayout *controlbar2 =new QHBoxLayout();

    controlbar->addWidget(b_pase);controlbar->addWidget(b_start);
    controlbar->addWidget(fullScreen);controlbar1->addLayout(controlbar2);
    controlbar1->addLayout(controlbar);top->addWidget(lab1);
    top->addWidget(videoWidget);top->addLayout(controlbar1);

    QHBoxLayout *all = new QHBoxLayout();QVBoxLayout *right = new QVBoxLayout();
    all->addLayout(top);QPushButton *search = new QPushButton();
    search->setText("search");right->addWidget(scroll);

    all->addLayout(right);all->setStretchFactor(videoWidget, 3);window.setLayout(all);

    window.setMinimumSize(800, 680);window.setGeometry(40, 40, 800, 680);

    QPushButton::connect(fullScreen,SIGNAL(clicked()),videoWidget,SLOT(showFull()));

    // showtime!
    window.show(); return app.exec();
}
// total 49 lines
